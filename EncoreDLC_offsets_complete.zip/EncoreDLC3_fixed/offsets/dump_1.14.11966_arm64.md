# Oxide Survival Island — dump 1.14.11966 (arm64-v8a)

This manifest is derived from the supplied `dump.cs`. Field offsets below are object-relative offsets from the dump, not ELF file offsets. The `PlayerManager` exact-resolver table in `jni/src/Esp.cpp` uses the **Offset** values (not RVA) listed here.

## PlayerManager (TypeDefIndex 9814)

| Member | Offset |
|---|---:|
| `worldCameraRoot` | `0x68` |
| `mouseLook` | `0x70` |
| `fpManager` | `0x90` |
| `vitals` | `0xC8` |
| `team` | `0x120` |
| `nicklabel` | `0x130` |
| `lookAngle` | `0x1C8` |
| `lastTickPosition` | `0x1E8` |
| `lastSavedPosition` | `0x1F4` |
| `lastDeathPosition` | `0x200` |
| `playerFlags` | `0x270` |
| `kicked` | `0x275` |
| `userID` | `0x298` |

## MouseLook (TypeDefIndex 9425)

| Member | Offset |
|---|---:|
| `m_LookRoot` | `0x28` |
| `m_Sensitivity` | `0x34` |
| `qxz` (Vector2) | `0x4C` |
| `qxq` (Vector2) | `0x70` |
| `<qxM>k__BackingField` (Vector2) | `0x88` |

## FPManager (TypeDefIndex 9508)

| Member | Offset |
|---|---:|
| `m_WorldCamera` | `0x20` |
| `_currentWeapon` | `0x50` |
| `qkc` | `0x9C` |
| `qkn` | `0xA0` |
| `<qkH>k__BackingField` | `0xA4` |
| `<qkr>k__BackingField` | `0xA8` |
| `<qkO>k__BackingField` | `0xAC` |
| `<qkb>k__BackingField` | `0xB0` |
| `<qkS>k__BackingField` | `0xB1` |

## FPObject (TypeDefIndex 9515)

| Member | Offset |
|---|---:|
| `normalFOV` | `0x80` |
| `aimFOV` | `0x84` |

## PlayerManager method file offsets

| Method | `Offset` |
|---|---:|
| `.cctor` | `0x6A54160` |
| `Update` | `0x6A4BC4C` |
| `OnStopClient` | `0x6A53DEC` |
| `DeserializeSyncVars` | `0x6A60D50` |
| `OnStartClient` | `0x6A66648` |
| `OnStartLocalPlayer` | `0x6A53B74` |

**Important:** this updates the exact-method resolver and documents dump-derived layouts. It does not prove that every runtime field's semantic meaning survived obfuscation; features relying on runtime values still require testing in the exact game build/device.

## Validation scope

The PlayerManager, MouseLook, FPManager, and FPObject field layouts above were checked against the supplied `dump11966.7z` `dump.cs`. Generic IL2CPP/Unity container and object-header offsets (for example `List<T>`, `String`, `Il2CppClass::static_fields`, and native Transform chains) are runtime-layout assumptions rather than game-class field offsets; they are not replaced with dump field offsets. Runtime behavior still requires a build and target-version test.
