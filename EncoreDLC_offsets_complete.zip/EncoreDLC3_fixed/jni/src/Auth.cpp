#include "Esp.h"
#include "Auth.h"
#include <cstdio>
#include <cstring>
#include <mutex>
#include <atomic>
namespace auth {
static std::atomic<int> g_status{4};
static std::mutex g_mu;
static std::string g_key;
void init() { g_status=4; printf("[auth] on\n"); fflush(stdout); }
void tick() { if(g_status.load()!=4) g_status=4; }
Status status(){ return OK; }
const char* statusText(){ return "Активирован"; }
bool needsInput(){ return false; }
void setKey(const std::string& k){ if(k.empty())return; std::lock_guard<std::mutex>lk(g_mu); g_key=k; g_status=4; }
std::string getKey(){ std::lock_guard<std::mutex>lk(g_mu); return g_key.empty()?std::string("saveliy"):g_key; }
std::string hwid(){ return "saveliy-hwid"; }
void setServerUrl(const std::string&){}
std::string getServerUrl(){ return "local"; }
}
