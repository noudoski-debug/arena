# ESP frame-time fix

## Change
- `jni/src/Esp.cpp`: the render cache now copies `s_world` only when `s_snapshotSeq` changes, instead of copying the full entity vector (including `std::string` names) on every overlay frame.
- Reset the render sequence when the target PID changes, so the cache is refreshed for a new process.

## Why this matters
The overlay can render at display rate while snapshots are collected at a lower rate. Previously, every render frame copied the whole entity vector and its string fields even when no new snapshot existed. That creates avoidable allocations and CPU work, especially on Android.

## Build / validation
Build with the project's existing command:
`NDK_PATH=$HOME/ndk/android-ndk-aide bash build.sh V=1`

Check the verbose output to confirm `Esp.cpp` is compiled. This archive contains a source patch; it has not been built or FPS-profiled in this environment. If the overlay still runs near 10 FPS, enable the project's ESP debug logging and capture timings; the remaining likely cost is synchronous `collectSnapshot()` / remote-memory reads, which needs profiling on-device before changing its scheduling.
