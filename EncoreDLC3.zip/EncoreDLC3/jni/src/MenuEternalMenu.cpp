#include "menu.hpp"
#include "LitvinMenu.h"
#include "Vars.h"
#include "Bind.h"
#include "imgui.h"

// LitvinMenu — header-only: Settings/cfg не существует.
// Меню читает/пишет Vars.* напрямую внутри LitvinMenu.h::Render().
// pullSettings/pushSettings не нужны.

namespace menu {
namespace {

void drawWatermark() {
    if (!Vars.Menu.watera) return;
    ImDrawList* d = ImGui::GetBackgroundDrawList();
    const ImVec2 p(12.0f, 12.0f), q(222.0f, 54.0f);
    d->AddRectFilled(ImVec2(p.x-3, p.y-3), ImVec2(q.x+3, q.y+3),
                     IM_COL32(10,132,255,28), 14.0f);
    d->AddRectFilled(p, q, IM_COL32(18,20,27,238), 12.0f);
    d->AddRect(p, q, IM_COL32(56,145,255,220), 12.0f, 0, 1.1f);
    d->AddCircleFilled(ImVec2(28,33), 7.0f, IM_COL32(10,132,255,70), 24);
    d->AddCircleFilled(ImVec2(28,33), 3.2f, IM_COL32(88,190,255,255), 24);
    d->AddText(ImVec2(42,21), IM_COL32(248,249,252,255), "EncoreDLC");
    d->AddText(ImVec2(42,37), IM_COL32(136,174,222,255), "LITVIN TAP  /  ANDROID");
}

} // namespace

void render() {
    if (bind::consumeMenuToggle()) Vars.Menu.openmenu = !Vars.Menu.openmenu;

    // Тап по вотермарке тоже открывает/закрывает меню
    if (Vars.Menu.watera && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
        const ImVec2 p = ImGui::GetIO().MousePos;
        if (p.x >= 9.0f && p.x <= 225.0f && p.y >= 9.0f && p.y <= 57.0f)
            Vars.Menu.openmenu = !Vars.Menu.openmenu;
    }

    drawWatermark();

    // Синхронизируем LitvinMenu::open <-> Vars.Menu.openmenu
    LitvinMenu::open = Vars.Menu.openmenu;
    LitvinMenu::Render();
    Vars.Menu.openmenu = LitvinMenu::open;
}

} // namespace menu
