// Aim.cpp — AimBot (угловой) + SilentAim (Magic Bullets)
// Dump 1.14.11949:
//   MouseLook.qxq.x  = ml+0x50   (накопленный yaw, float)
//   lookAngle (pitch) = PlayerManager+0x1C8
//   lastTickPosition  = PlayerManager+0x1E8
//
// smooth: 0 = мгновенно (держит точно на голове), 100 = очень медленно.
// SilentAim независим от обычного аим — работает сам по себе.
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "Aim.h"
#include "Esp.h"
#include "MenuStubs.h"
#include "RemotePatch.h"
#include "Bind.h"
#include "ImGui/imgui.h"

#include <cstdio>
#include <cstring>
#include <cmath>

namespace aim {
namespace {

static const char* kGamePkg = "com.catsbit.oxidesurvivalisland";

// smooth=0  → response=60 (snap за 1 кадр при 60fps)
// smooth=100 → response=0.5 (очень медленно, ~2 секунды)
static float smoothToResponse(float s) {
    if (s < 0.f)   s = 0.f;
    if (s > 100.f) s = 100.f;
    // логарифмическое распределение: 0→60, 50→6, 100→0.5
    float t = s / 100.f;
    return 60.f * powf(0.5f / 60.f, t);
}

} // namespace

// ── FOV-круги (рисуем всегда, независимо от bind/scope) ─────────────────────
static void drawOverlays(int screenW, int screenH) {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    float cx = (float)screenW * 0.5f, cy = (float)screenH * 0.5f;

    if (Vars.Aimbot.drawfov && Vars.Aimbot.enableAimbot) {
        float r = Vars.Aimbot.fovcheck ? Vars.Aimbot.fov : 120.f;
        if (r < 5.f)  r = 5.f;
        float maxR = (screenH < screenW ? (float)screenH : (float)screenW) * 0.5f;
        if (r > maxR) r = maxR;
        dl->AddCircle(ImVec2(cx, cy), r, IM_COL32(255,255,255,200), 64, 1.5f);
        dl->AddCircleFilled(ImVec2(cx, cy), 2.5f, IM_COL32(255,255,255,200));
    }

    if (Vars.Aimbot.silentAim) {
        float r = Vars.Aimbot.silentFov;
        if (r < 5.f) r = 5.f;
        // пунктирный круг — отличие от обычного fov
        const int segs = 48;
        for (int i = 0; i < segs; i += 2) {
            float a0 = (float)i       / segs * 2.f * 3.14159f;
            float a1 = (float)(i + 1) / segs * 2.f * 3.14159f;
            dl->AddLine(
                ImVec2(cx + cosf(a0) * r, cy + sinf(a0) * r),
                ImVec2(cx + cosf(a1) * r, cy + sinf(a1) * r),
                IM_COL32(255, 200, 60, 220), 1.5f);
        }
    }
}

// ── Silent Aim (Magic Bullets) ───────────────────────────────────────────────
// Работает независимо от enableAimbot.
// Читает цель в silentFov, пишет lastTickPosition локального игрока = позиция
// выбранной кости цели. Сервер считает что пуля прилетела оттуда → хит.
// Через один кадр позиция восстанавливается.
static void tickSilent(int pid) {
    if (!Vars.Aimbot.silentAim) return;

    // scope check для silent
    if (Vars.Aimbot.silentScopeCheck && !esp::isScoped()) return;

    float fovPx = Vars.Aimbot.silentFov;
    esp::AimWrite aw;
    int boneIdx = Vars.Aimbot.silentBoneIndex;
    if (boneIdx < 0 || boneIdx > 5) boneIdx = 0;

    // visibleOnly фильтр применяется внутри aimAngles через флаг
    if (!esp::aimAngles(boneIdx, fovPx, aw, Vars.Aimbot.silentVisibleOnly)) return;
    if (!aw.localPosAddr) return;

    // Один-кадровое восстановление предыдущей подмены
    static bool      s_needRestore = false;
    static float     s_savedX = 0, s_savedY = 0, s_savedZ = 0;
    static uintptr_t s_savedAddr = 0;

    if (s_needRestore && s_savedAddr) {
        rpatch::writeF32(pid, s_savedAddr,     s_savedX);
        rpatch::writeF32(pid, s_savedAddr + 4, s_savedY);
        rpatch::writeF32(pid, s_savedAddr + 8, s_savedZ);
        s_needRestore = false;
    }

    // Читаем текущую позицию локального игрока
    float lx = 0, ly = 0, lz = 0;
    if (!rpatch::readF32(pid, aw.localPosAddr,     lx) ||
        !rpatch::readF32(pid, aw.localPosAddr + 4, ly) ||
        !rpatch::readF32(pid, aw.localPosAddr + 8, lz)) return;

    // Сохраняем для восстановления
    s_savedX    = lx;
    s_savedY    = ly;
    s_savedZ    = lz;
    s_savedAddr = aw.localPosAddr;
    s_needRestore = true;

    // Пишем позицию = кость цели (Magic Bullet телепортирует origin пули)
    rpatch::writeF32(pid, aw.localPosAddr,     aw.targetX);
    rpatch::writeF32(pid, aw.localPosAddr + 4, aw.targetY);
    rpatch::writeF32(pid, aw.localPosAddr + 8, aw.targetZ);
}

// ── Обычный AimBot ───────────────────────────────────────────────────────────
static void tickAimbot(int pid, int screenW, int screenH) {
    if (!Vars.Aimbot.enableAimbot) return;

    // bind check
    bool bindOk = false;
    {
        int b = Vars.Aimbot.aimBind;
        if (b == 0)   bindOk = true;
        else if (b == 273 && !Vars.Aimbot.scopeCheck) bindOk = true;
        else if (b == 273 &&  Vars.Aimbot.scopeCheck && esp::isScoped()) bindOk = true;
        else bindOk = bind::isDown(b);
    }
    if (!bindOk) return;
    if (Vars.Aimbot.scopeCheck && !esp::isScoped()) return;

    float dt = ImGui::GetIO().DeltaTime;
    if (!(dt > 0.001f && dt < 0.1f)) dt = 1.0f / 60.0f;

    // Уступаем камеру: если юзер сам вертит — пропускаем тик
    {
        static float pYaw = 0, pPitch = 0;
        static bool  haveP = false;
        float ey0 = 0, ep0 = 0;
        esp::lookDbgGet(ey0, ep0);
        if (haveP) {
            float dy = fabsf(ey0 - pYaw);
            if (dy > 180.f) dy = 360.f - dy;
            if (dy > 12.f || fabsf(ep0 - pPitch) > 8.f) {
                pYaw = ey0; pPitch = ep0; return;
            }
        }
        pYaw = ey0; pPitch = ep0; haveP = true;
    }

    float fovPx = Vars.Aimbot.fovcheck ? Vars.Aimbot.fov : 9999.f;
    esp::AimWrite aw;
    int boneIdx = Vars.Aimbot.selectedBoneIndex;
    if (boneIdx < 0 || boneIdx > 5) boneIdx = 0;

    if (!esp::aimAngles(boneIdx, fovPx, aw, Vars.Aimbot.visibleOnly)) return;
    if (!aw.yawAddr || !aw.lookAddr) return;

    float yawErr   = aw.yawErr;
    float pitchErr = aw.pitchErrUp;
    if (sqrtf(yawErr * yawErr + pitchErr * pitchErr) < 0.002f) return;

    // smooth=0 → response=60 → blend≈1 за кадр (снап)
    // smooth=100 → response=0.5 → blend≈0.008 (очень медленно)
    float response = smoothToResponse(Vars.Aimbot.smooth);
    // бонус скорости для движущихся целей
    response += fminf(10.0f, aw.targetSpeed * 1.35f);
    float blend = 1.0f - expf(-response * dt);

    float newYaw  = aw.curYawRaw + yawErr   * blend;
    float newLook = aw.curLook   - pitchErr * blend;
    if (newLook >  85.f) newLook =  85.f;
    if (newLook < -85.f) newLook = -85.f;

    rpatch::writeF32(pid, aw.yawAddr,  newYaw);
    rpatch::writeF32(pid, aw.lookAddr, newLook);
    if (aw.pitchMirrorAddr)
        rpatch::writeF32(pid, aw.pitchMirrorAddr, newLook);
}

void tick(int screenW, int screenH) {
    drawOverlays(screenW, screenH);
    if (Vars.Menu.openmenu) return;

    int pid = rpatch::pidOf(kGamePkg);
    if (pid <= 0) return;

    tickSilent(pid);
    tickAimbot(pid, screenW, screenH);
}

} // namespace aim
